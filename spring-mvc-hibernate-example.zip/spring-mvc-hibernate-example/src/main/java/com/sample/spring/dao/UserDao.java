package com.sample.spring.dao;

import java.util.List;

import com.sample.spring.model.User;

public interface UserDao {
   void save(User user);
   List<User> list();
}
