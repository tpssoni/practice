package com.sample.spring.service;

import java.util.List;

import com.sample.spring.model.User;

public interface UserService {
   void save(User user);

   List<User> list();
}
