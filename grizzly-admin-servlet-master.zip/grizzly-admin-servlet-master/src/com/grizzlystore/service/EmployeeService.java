package com.grizzlystore.service;

import com.grizzlystore.bean.Profile;

public interface EmployeeService {
	
	public int registerUser(Profile employee);

}
