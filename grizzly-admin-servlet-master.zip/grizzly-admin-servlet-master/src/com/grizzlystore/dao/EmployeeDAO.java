package com.grizzlystore.dao;

import com.grizzlystore.bean.Profile;

public interface EmployeeDAO {
	public int registerUser(Profile employee);
}
