package com.grizzlystore.dao;

import java.util.List;

import com.grizzlystore.bean.Category;

public interface CategoryDAO {
	public List<Category> getCategory();

}
