package com.grizzlystore.service;

import java.util.List;

import com.grizzlystore.bean.Category;

public interface CategoryService {
	public List<Category> getCategory();
}
