package com.grizzlystore.dao;

import com.grizzlystore.bean.Vendors;

public interface VendorDAO {
	
	public Vendors getVendorById(String id);
}
