package com.cts.product.dao;

import com.cts.product.bean.Login;

public class LoginDAOImpl implements LoginDAO{

	public int getUserStatus(String id) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getUserType(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Login authenticate(String userName, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
