package com.cts.product.dao;

import java.util.List;

import com.cts.product.bean.Product;

public class ProductDAOImpl implements ProductDAO{

	public String insertProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	public String updateProduct(String id, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product getProductById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Product> getProductByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
