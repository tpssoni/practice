package com.cts.employeemanagementsystem.dao;

public interface empDelDAO {
	public String delete(String condition) ;

}
