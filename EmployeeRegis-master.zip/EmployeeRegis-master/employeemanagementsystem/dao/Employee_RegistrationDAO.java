package com.cts.employeemanagementsystem.dao;

public interface Employee_RegistrationDAO {
	public String insert(String id,String fn,String ln,int sal);
	
	public String update(String tupple,String change);


	
}
