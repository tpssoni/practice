package com.cts.employeemanagementsystem.service;

public interface empDelService {
	public String delete(String condition) ;

}
