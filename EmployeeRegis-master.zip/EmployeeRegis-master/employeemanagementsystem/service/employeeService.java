package com.cts.employeemanagementsystem.service;

public interface employeeService {
	public String insert(String id,String fn,String ln,int sal);
	public String update(String tupple,String change);

}
